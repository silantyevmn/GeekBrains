package ru.silantyevmn;

/**
 * ru.silantyevmn
 * Created by Михаил Силантьев on 04.01.2018.
 */
public interface Poolable {
    boolean isActive();
}
